package stlab;

import java.util.*;

public class prg2 
{
    public String check(int a,int b,int c)
    {
   	 if((a>=1 && a<=200) && (b>=1 && b<=200) && (c>=1 && c<=200))
		{
			if((a+b>c) && (b+c>a) && (c+a>b))
			{
				if(a==b && b==c )
				{
					return "Equilateral";
				}
				else if(a==b || b==c || c==a)
				{
					 return "Isosceles";
				}
				else
				{
					return "Scalene";
				}
			}
			else
			{
				return "Not a Triangle";
			}
		}
		else
		{
			return "Invalid Values";
		}
    }
    
    public static void main(String[] args)
    {
    	Scanner sc=new Scanner(System.in);
        prg2 t=new prg2();
        System.out.println("Enter the sides of a triangle");
        int a=sc.nextInt();
        int b=sc.nextInt();
        int c=sc.nextInt();
        System.out.println(t.check(a, b, c));
    }
}
