package stlab;

import java.util.*;
class Check {
int checkPin(int p,int i){
if(p==i)
return 1;
System.out.println("Invalid PIN number");
return 0;
}
int checkAccount(int t){
if(t==1){
System.out.println("Opened Savings account");
return 1;
}
else if(t==2){
System.out.println("Opened Current account");
return 1;
}
else{
System.out.println("Invalid Account Type");
return 0;
}
}
void checkBal(int bal){
System.out.println("Your available balance is="+bal);
}
int withdraw(int a,int b){
if(a>b){
System.out.println("Insuffecient funds");
return 0;
}
b=b-a;
System.out.println("Successful transaction");
checkBal(b);
return b;
}
int deposit(int a,int b){
b=b+a;
System.out.println("Successful transaction");
checkBal(b);
return b;
}
}
public class prg1 {
public static void main(String[] args) {
// TODO Auto-generated method stub
Scanner sc=new Scanner(System.in);
Check obj=new Check();
int r,pass=5555,k=0,balance=5000;
int inp;
System.out.println("1NH19CS162");
while(k<3){
System.out.println("Enter PIN number");
inp=sc.nextInt();
r=obj.checkPin(pass,inp);
if(r==1){
System.out.println("\nWelcome\n");
break;
}
k++;
}
if(k==3){
System.out.println("Ttransaction Terminated");
System.exit(0);
}
r=0;
while(r==0){
System.out.println("Enter the account type\n1-Savings\n2-Current\n");
int type=sc.nextInt();
r=obj.checkAccount(type);
}
int trans=0;
while(trans!=4){
System.out.println("Select transaction:\n\n1-Check Balance\n2-Withdraw\n3-Deposit\n4-Exit\n");
trans=sc.nextInt();
switch(trans){
case 1:
obj.checkBal(balance);
break;
case 2:
System.out.println("Enter the amount you want to withdraw");
int amt=sc.nextInt();
if(amt%500!=0){
System.out.println("Invalid amount");
}
else{
r=obj.withdraw(amt,balance);
balance=r;
};
break;
case 3:
System.out.println("Enter the amount you want to deposit");
int amt2=sc.nextInt();
int b=obj.deposit(amt2,balance);
balance=b;
break;
}
}}}