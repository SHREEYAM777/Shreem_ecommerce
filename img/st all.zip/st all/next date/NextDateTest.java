package stlab;

import static org.junit.Assert.*;
import org.junit.Test;

public class NextDateTest
{ //1NH19CS162
	prg3 obj = new prg3();
	 
	   @Test
		public void test1() {
			assertEquals(obj.nextday(0, 1,1812),"Invalid Values");
		}
		@Test
		public void test2() {
			assertEquals(obj.nextday(1, 0,1812),"Invalid Values");
		}
		@Test
		public void test3() {
			assertEquals(obj.nextday(1, 1,1811),"Invalid Values");
		}
		@Test
		public void test4() {
			assertEquals(obj.nextday(1, 2,1812),"2.2.1812");
		}
		@Test
		public void test5() {
			assertEquals(obj.nextday(31, 1,1812),"1.2.1812");
		}
		@Test
		public void test6() {
			assertEquals(obj.nextday(28, 2,2000),"29.2.2000");
		}
		@Test
		public void test7() {
			assertEquals(obj.nextday(28, 2,2001),"1.3.2001");
		}
		@Test
		public void test8() {
			assertEquals(obj.nextday(31, 12,2001),"1.1.2002");
		}
		@Test
		public void test9() {
			assertEquals(obj.nextday(30, 12,2001),"31.12.2001");
}
		@Test
		public void test10() {
			assertEquals(obj.nextday(15, 6,1912),"16.6.1912");
		}
		@Test
		public void test11() {
			assertEquals(obj.nextday(31, 10,2012),"1.11.2012");
		}
		@Test
		public void test12() {
			assertEquals(obj.nextday(31, 4,2012),"Invalid Values");
		}
		@Test
		public void test13() {
			assertEquals(obj.nextday(30, 4,2012),"1.5.2012");
		}
		@Test
		public void test14() {
			assertEquals(obj.nextday(29, 2,2001),"Invalid Values");
		}
		@Test
		public void test15() {
			assertEquals(obj.nextday(31, 10,2013),"Invalid Values");
		}
		@Test
		public void test16() {
			assertEquals(obj.nextday(0, 10,2011),"Invalid Values");
		}
		@Test
		public void test17() {
			assertEquals(obj.nextday(32, 10,2011),"Invalid Values");
		}
		@Test
		public void test18() {
			assertEquals(obj.nextday(10, 0,2011),"Invalid Values");
		}
		@Test
		public void test19() {
			assertEquals(obj.nextday(10, 13,2011),"Invalid Values");
		}
		@Test
		public void test20() {
			assertEquals(obj.nextday(10, 11,1811),"Invalid Values");
		}
		@Test
		public void test21() {
			assertEquals(obj.nextday(10, 0,1811),"Invalid Values");
		}

}