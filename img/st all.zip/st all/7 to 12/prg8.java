package stlab;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;
public class prg8 {
public static void main(String[] args) throws InterruptedException
{

System.setProperty("webdriver.chrome.driver"
,"C:\\Users\\Student\\Desktop\\ST\\chromedriver.exe");
// Creating a object to instantiate the browser driver
ChromeDriver driver = new ChromeDriver();
driver.get("C:\\Users\\Student\\Desktop\\Login.html");
//maximizing browser with maximize() � � � � �
driver.manage().window().maximize();

driver.findElement(By.name("userName")).sendKeys("mercury1");
driver.findElement(By.name("password")).sendKeys("mercury1");
//Thread.sleep(5000);
driver.findElement(By.name("submit")).click();
}}