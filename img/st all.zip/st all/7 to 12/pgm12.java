package stlab;

import java.util.concurrent.TimeoutException;
import org.openqa.selenium.*;
import org.openqa.selenium.chrome.ChromeDriver;
import java.time.Duration;
import org.openqa.selenium.support.ui.*;


public class pgm12 {

public static void main(String[] args) {
System.setProperty("webdriver.chrome.driver","C:\\Users\\Student\\Desktop\\ST\\chromedriver.exe");

ChromeDriver driver=new ChromeDriver();
driver.manage().window().maximize();
driver.get("C:\\Users\\Student\\Desktop\\welcome.html");
String eText="Welcome";
String aText1="";
String aText2="";
WebDriverWait wait=new WebDriverWait(driver,Duration.ofSeconds(10,1));
try{
WebElement
text_1=wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("welcome")));
aText1=text_1.getText();
if(aText1.equals(eText))
System.out.println("Test 1 Passes using Explicit Wait");}
catch(Exception e){
System.out.println("Test 1 failed using Explicit Wait");}
try{
WebElement
text_2=wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("abcd")));
aText2=text_2.getText();
if(aText2.equals(eText))
System.out.println("Test 2 Passes using Explicit Wait");}
catch(Exception e){
System.out.println("Test 2 failed using Explicit Wait");
}System.out.println("1NH19CS162");}}