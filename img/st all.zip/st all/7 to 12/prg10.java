package stlab;


import org.openqa.selenium.chrome.ChromeDriver;

public class prg10 {
	public static void main(String[] args)
	{
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\Student\\Desktop\\ST\\chromedriver.exe");
		ChromeDriver driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.get("https://sites.google.com/view/bhaskartime/home");
		String title=driver.getTitle();
		System.out.println("Current title:"+title);
		if(title.equals("bhaskartime"))
			System.out.println("Title matches!");
		else
			System.out.println("Title doesnt match:");
		System.out.println("1NH19CS162");
			
	}

}
     