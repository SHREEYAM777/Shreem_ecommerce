package stlab;


import java.util.concurrent.TimeUnit;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;


public class prg12 {
	public static void main(String[] args) {
     
    	System.setProperty("webdriver.chrome.driver", 
				"C:\\Users\\Student\\Desktop\\ST\\chromedriver.exe");
		 ChromeDriver driver = new ChromeDriver();
		 driver.manage().window().maximize();
		 String eText = "Welcome"; 	
			String aText_1="";			
			String aText_2="";			

		 
		 driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		 driver.get("C:\\Users\\Student\\Desktop\\welcome.html");
		 		 
		 try{
				aText_1 = driver.findElement(By.id("welcome")).getText();
				if (aText_1.equals(eText))
				System.out.println("Test 1 Passed using Implicit Wait");
			}
			catch (NoSuchElementException e){
				System.out.println("Test 1 Failed using Implicit Wait");
			}
    
		
			try{
				aText_2 = driver.findElement(By.id("abcd")).getText();
				if (aText_2.equals(eText))
				System.out.println("Test 2 Passed using Implicit Wait");
			}
			catch (NoSuchElementException e){
			System.out.println("Test 2 Failed using Implicit Wait");
			}
		
         driver.quit(); 
         System.out.println("1NH19CS162");}  
	}