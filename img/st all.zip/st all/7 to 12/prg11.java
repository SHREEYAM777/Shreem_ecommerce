package stlab;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class prg11 {

	public static void main(String args[]) {

      
        WebDriver driver = new ChromeDriver();

       
        driver.get("file:///C:/Users/Student/Desktop/a.html");

      
        driver.manage().window().maximize();

      
        Select select = new Select(driver.findElement(By.id("days")));

       
        List<WebElement> lst = select.getOptions();

       
        System.out.println("The dropdown options are:");
        for(WebElement options: lst)
            System.out.println(options.getText());

        System.out.println("Select the Option by Index 3");
        select.selectByIndex(3);
        System.out.println("Select value is: " + select.getFirstSelectedOption().getText());
       
        
        System.out.println("Select the Option by Text");
        select.selectByVisibleText("Wednesday");
        System.out.println("Select value is: " + select.getFirstSelectedOption().getText());
      
       
        System.out.println("Select the Option by value ");
        select.selectByValue("mon");
        System.out.println("Select value is: " + select.getFirstSelectedOption().getText());
       
        
        System.out.println("Deselect the Option by Index 3");
        select.deselectByIndex(3);
       
        
        System.out.println("DeSelect the Option by Text Wednesday ");
        select.deselectByVisibleText("Wednesday");
    
      
        System.out.println("The selected values after deselecting some options are: ");
 		lst = select.getAllSelectedOptions();
 		for(WebElement option: lst)
	 		System.out.println(option.getText());
 		System.out.println("Deselecting all options.");
 		select.deselectAll();
System.out.println("1NH19CS162");
 		

        
    }
}

