package stlab;

import static org.junit.Assert.*;
import org.junit.Test;
public class TriangleTest {
//1NH19CS162
Triangle t= new Triangle();
@Test
public void test()
{
assertEquals(t.check(20,20,50),"Not a Triangle");
}
@Test
public void test1()
{
assertEquals(t.check(50,200,50),"Not a Triangle");
}
@Test
public void test2()
{
assertEquals(t.check(20,30,70),"Not a Triangle");
}
@Test
public void test3()
{
assertEquals(t.check(100,100,100),"Equilateral");
}
@Test
public void test4()
{
assertEquals(t.check(100,101,105),"Scalene");
}

@Test
public void test5()
{
assertEquals(t.check(40,60,40),"Isosceles");
}
@Test
public void test6()
{
assertEquals(t.check(100,100,2),"Isosceles");
}
@Test
public void test7()
{
assertEquals(t.check(100,100,55),"Isosceles");
}

@Test
public void test8()
{
assertEquals(t.check(199,100,100),"Isosceles");
}
@Test
public void test10()
{
assertEquals(t.check(100,100,200),"Not a Triangle");
}
@Test
public void test11()
{
assertEquals(t.check(0,200,100),"Invalid Values");
}
@Test
public void test12()
{
assertEquals(t.check(201,200,100),"Invalid Values");
}
@Test
public void test13()
{
assertEquals(t.check(200,200,500),"Invalid Values");
}
@Test
public void test14()
{
assertEquals(t.check(0,200,500),"Invalid Values");
}
@Test
public void test15()
{
assertEquals(t.check(200,0,200),"Invalid Values");
}
@Test
public void test16()
{
assertEquals(t.check(0,0,200),"Invalid Values");
}}