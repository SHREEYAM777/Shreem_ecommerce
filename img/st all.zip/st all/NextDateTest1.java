package stlab;

import static org.junit.Assert.*;

import org.junit.Test;

public class NextDateTest1
{ //1NH19CS162
	prg3 ob1 = new prg3();
//weak and strong normal test case
@Test
public void test1()
{

assertEquals(ob1.nextday(15,6,1919),"16.6.1919");
}
// Weak Robust
@Test
public void test2()
{

assertEquals(ob1.nextday(0,6,1912),"Invalid Values");
}
@Test
public void test3()
{

assertEquals(ob1.nextday(32,6,1900),"Invalid Values");
}
@Test
public void test4()
{

assertEquals(ob1.nextday(10,0,1912),"Invalid Values");
}
@Test
public void test5()
{

assertEquals(ob1.nextday(20,13,2010),"Invalid Values");
}
public void test6()
{

assertEquals(ob1.nextday(20,10,1811),"Invalid Values");
}
@Test
public void test7()
{

assertEquals(ob1.nextday(20,10,2020),"Invalid Values");
}
//Strong Robust
@Test
public void test8()
{

assertEquals(ob1.nextday(20,13,2013),"Invalid Values");
}
@Test
public void test9()
{

assertEquals(ob1.nextday(0,13,2010),"Invalid Values");
}
@Test
public void test10()
{

assertEquals(ob1.nextday(32,13,2010),"Invalid Values");
}
@Test
public void test11()
{

assertEquals(ob1.nextday(20,13,1811),"Invalid Values");
}
@Test
public void test12()
{

assertEquals(ob1.nextday(0,10,2013),"Invalid Values");
}
@Test
public void test13()
{

assertEquals(ob1.nextday(32,13,1811),"Invalid Values");
}
@Test
public void test14()
{

assertEquals(ob1.nextday(0,13,2013),"Invalid Values");
}
@Test
public void test15()
{

assertEquals(ob1.nextday(32,0,1811),"Invalid Values");
}
}