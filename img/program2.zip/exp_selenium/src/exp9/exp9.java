package exp9;
import org.openqa.selenium.By;
import java.util.List;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
public class exp9 {
public static void main(String args[]){
System.setProperty("webdriver.chrome.driver", "C:\\Users\\Shreeyam Chaturvedi\\Downloads\\st_exp\\chromedriver.exe");
ChromeDriver driver = new ChromeDriver();
driver.manage().window().maximize();
driver.get("https://www.msn.com");
List<WebElement> linksList = driver.findElements(By.xpath("//a"));
int linkCount = linksList.size();
System.out.println("1nh19cs166_shreeyam");
System.out.println("Total number of links in the webpage: "+linkCount);
List<WebElement> elementsList = driver.findElements(By.xpath("//*"));



int elementsCount = elementsList.size();
System.out.println("Total number of elements in the webpage: "+elementsCount);
}
}