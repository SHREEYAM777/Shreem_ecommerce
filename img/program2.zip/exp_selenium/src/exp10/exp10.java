package exp10;
import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;
public class exp10 {
public static void main(String args[]){
System.out.println("1NH19CS166 Shreeyam");
System.setProperty("webdriver.chrome.driver", "C:\\Users\\Shreeyam Chaturvedi\\Downloads\\st_exp\\chromedriver.exe");
ChromeDriver driver = new ChromeDriver();
driver.manage().window().maximize();
driver.get("https://en.wikipedia.org/wiki/Wikipedia");
String url = driver.getCurrentUrl();
System.out.println("Current URL: " + url);
if(url.equals("https://en.wikipedia.org/wiki/Wikipedia"))
System.out.println("URL matches!");
else
System.out.println("URL doesn't match.");
driver.get("https://www.google.com");
String title = driver.getTitle();
System.out.println("Current Title: " + title);
if(title.equals("Google"))
System.out.println("Title matches!");
else
System.out.println("Title doesn't match.");
}
}