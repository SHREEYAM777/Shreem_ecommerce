package exp8;
import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;
public class exp8 {
public static void main(String args[]){
System.setProperty("webdriver.chrome.driver", "C:\\Users\\Shreeyam Chaturvedi\\Downloads\\st_exp\\chromedriver.exe");
ChromeDriver driver = new ChromeDriver();
driver.manage().window().maximize();
driver.get("file:///C:/Users/Shreeyam%20Chaturvedi/Downloads/loginst.html");
System.out.println("1NH19CS166 Shreeyam");
driver.findElement(By.name("username")).sendKeys("rahulmd");
driver.findElement(By.name("password")).sendKeys("12345");
driver.findElement(By.name("submit")).click();
}
}