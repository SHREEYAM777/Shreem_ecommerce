package exp11;
import java.util.List;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;
public class exp11 {
public static void main(String[] args) throws InterruptedException {
System.setProperty("webdriver.chrome.driver", "C:\\Users\\Shreeyam Chaturvedi\\Downloads\\st_exp\\chromedriver.exe");
ChromeDriver driver = new ChromeDriver();
driver.manage().window().maximize();
System.out.println("1NH19CS166 Shreeyam");
driver.get("file:///C:/Users/Shreeyam%20Chaturvedi/Downloads/multiselect.html");
Select select = new Select(driver.findElement(By.id("depts")));
System.out.println("The multiselect options are: ");
List<WebElement> options = select.getOptions();
for(WebElement option: options)
System.out.println(option.getText());
System.out.println("Is the selected element a multiselect element?: "+ select.isMultiple());
if(select.isMultiple()){
System.out.println("Selecting option ECE using its index.");
select.selectByIndex(2);
Thread.sleep(4000);
System.out.println("Selecting option ISE using its value.");
select.selectByValue("ise");
Thread.sleep(4000);
System.out.println("Selecting option CSE using its visible text.");
select.selectByVisibleText("CSE");
Thread.sleep(4000);
System.out.println("The selected options are: ");
options = select.getAllSelectedOptions();
for(WebElement option: options)
System.out.println(option.getText());
System.out.println("Deselecting option ECE using its index.");
select.deselectByIndex(2);
Thread.sleep(4000);
System.out.println("Deselecting option ISE using its value.");
select.deselectByValue("ise");
Thread.sleep(4000);
System.out.println("The selected values after deselecting some options are: ");
options = select.getAllSelectedOptions();
for(WebElement option: options)
System.out.println(option.getText());
System.out.println("Deselecting all options.");
select.deselectAll();
}
}
}
